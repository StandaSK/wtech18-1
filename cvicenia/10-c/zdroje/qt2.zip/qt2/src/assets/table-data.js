export default [
  {
    id: 1,
    name: 'Televízor'
  },
  {
    id: 2,
    name: 'Mikrovlnná rúra'
  }
]
