<?php

namespace App\Http\Controllers;

use App\Image;
use App\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tasks = Task::all();
        return view('tasks.index',compact('tasks',$tasks));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tasks.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = $request->validate([
			'title' => 'required|min:3',
			'description' => 'required',
            'image' => 'nullable|image|mimes:jpeg,png|max:1024'
		]);

        $userId = Auth::id();
        $task = Task::create(['title' => $request->title,'description' => $request->description, 'user_id' => $userId]);

        $file = $validation['image'];
        $fileName = $task->id . '-' . md5($file->getClientOriginalName()) . time() . '.' . $file->getClientOriginalExtension();
        $uploadedFile = $file->storeAs(config('app.tasks-images-path'), $fileName);
        if ($uploadedFile) {
            Image::create(['file' => $fileName,'task_id' => $task->id]);
        } else {
            // ...
        }

        return redirect('/tasks/'.$task->id);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $task = Cache::remember('task-'. (int) $id, 60,
            function () use ($id) {
                return Task::find($id);
            });

        return view('tasks.show',compact('task',$task));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function edit(Task $task)
    {
        return view('tasks.edit',compact('task',$task));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Task $task)
    {
        $request->validate([
			'title' => 'required|min:3',
			'description' => 'required',
		]);  
         
		$task->title = $request->title;
		$task->description = $request->description;
		$task->save();
		$request->session()->flash('message', 'Úloha bola úspešne zmenená.');

        if (Cache::has('task-'.$task->id)) {
            Cache::forget('task-'.$task->id);
        }

		return redirect('tasks');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Task  $task
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Task $task)
    {
        $images = $task->images;
        foreach($images as $image) {
            $file = config('app.tasks-images-path') . $image->file;
            if (Storage::exists($file)) {
                Storage::delete($file);
            }
        }
        $task->images()->delete();
        $task->delete();
		$request->session()->flash('message', 'Úloha bola úspešne vymazaná');

        if (Cache::has('task-'.$task->id)) {
            Cache::forget('task-'.$task->id);
        }

		return redirect('tasks');
    }
}
