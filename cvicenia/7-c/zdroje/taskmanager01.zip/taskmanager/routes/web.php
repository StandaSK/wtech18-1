<?php

use Illuminate\Support\Facades\Config;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::resource('tasks', 'TaskController', ['middleware' => 'auth']);
*/

Route::middleware(['auth'])->group(function () {
    Route::get('/', 'TaskController@index');

    Route::get('tasks/', 'TaskController@index');
    Route::get('tasks/create/', 'TaskController@create');
    Route::post('tasks/', 'TaskController@store');

    // Route::get('tasks/{task}/', 'TaskController@show');
    Route::get('tasks/{id}/', 'TaskController@show');

    Route::get('tasks/{task}/edit/', 'TaskController@edit')->middleware('can:update,task');
    Route::put('tasks/{task}/', 'TaskController@update')->middleware('can:update,task');
    Route::delete('tasks/{task}/', 'TaskController@destroy')->middleware('can:delete,task');
});

Route::get('locale/{locale}', function ($locale) {
    if (in_array($locale,  config('app.supported_languages'))) {
        session(['app_locale' => $locale]);
    }
    return redirect()->back();
});


Auth::routes();
