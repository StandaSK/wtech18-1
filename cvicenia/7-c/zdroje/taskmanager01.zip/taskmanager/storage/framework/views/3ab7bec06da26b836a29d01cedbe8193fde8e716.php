<?php $__env->startSection('content'); ?>
<h1>Detail úlohy: <?php echo e($task->title); ?></h1>
<div class="jumbotron">
	<div class="h5">Názov</div>
    <p>
		<?php echo e($task->title); ?> 
    </p>
	<div class="h5">Opis</div>
	<p>
		<?php echo e($task->description); ?>

	</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>